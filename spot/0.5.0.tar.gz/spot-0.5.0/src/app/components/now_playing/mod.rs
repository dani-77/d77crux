#[allow(clippy::module_inception)]
mod now_playing;
pub use now_playing::*;

mod now_playing_model;
pub use now_playing_model::*;
