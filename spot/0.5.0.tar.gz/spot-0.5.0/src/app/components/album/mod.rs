#[allow(clippy::module_inception)]
mod album;
pub use album::AlbumWidget;
