#[allow(clippy::module_inception)]
mod user_details;
pub use user_details::*;

mod user_details_model;
pub use user_details_model::*;
