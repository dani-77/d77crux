mod album_header;
#[allow(clippy::module_inception)]
mod details;
mod details_model;
mod release_details;

pub use details::Details;
pub use details_model::DetailsModel;
