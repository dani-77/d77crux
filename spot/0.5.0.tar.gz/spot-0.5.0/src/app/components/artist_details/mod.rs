#[allow(clippy::module_inception)]
mod artist_details;
pub use artist_details::*;

mod artist_details_model;
pub use artist_details_model::*;
